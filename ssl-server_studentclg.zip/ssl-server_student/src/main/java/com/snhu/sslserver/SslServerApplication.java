package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
 
   public static String calHash(String name) throws NoSuchAlgorithmException{
	   MessageDigest md = MessageDigest.getInstance("SHA-256");
	   byte[]hash = md.digest(name.getBytes(StandardCharsets.UTF_8));
	   BigInteger number= new BigInteger(1,hash);
	   StringBuilder hexString = new StringBuilder(number.toString(16));
	   while(hexString.length()<32);
	   {
		   hexString.insert(0, '0');
		   
	   }
	   return hexString.toString();
   }
	@RequestMapping("/hash")
    public String myHash()throws NoSuchAlgorithmException{
    	String data = "Hello Cristian Gallegos!";
    	String hash =calHash(data);
        return "<p>data:"+data+"</p><p>Name of Cipher Algorithm used:SHA-256 Value: "+hash+"</p>";
    }
}